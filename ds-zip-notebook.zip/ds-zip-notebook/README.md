# Data Structures Mini-Notebook: Mastering `zip()`

This repo contains a small Jupyter (IPython) Notebook that teaches Python's built-in `zip()`
for data-structure use cases: parallel iteration, building dictionaries, unzipping, matrix
transposition, and handling unequal lengths safely.

## Quickstart

### Option A: venv + pip (lightweight)
```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
jupyter lab  # or: jupyter notebook
```

### Option B: conda
```bash
conda create -n zip-notebook python=3.11 -y
conda activate zip-notebook
pip install -r requirements.txt
jupyter lab  # or: jupyter notebook
```

Then open **notebooks/zip_mastery.ipynb**.

## What’s inside
- `notebooks/zip_mastery.ipynb` – the lesson + practice
- `requirements.txt` – runtime dependencies
- `.gitignore` – ignores venv, checkpoints, etc.
- `src/`, `data/` – placeholders if you want to expand the project

## Publish to GitHub

```bash
git init
git add .
git commit -m "Add zip() data-structures notebook"
git branch -M main
# Create an empty repo on GitHub (via web or gh CLI), then set your remote:
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

> Tip: If you use the GitHub web UI, you can also drag-and-drop the folder contents.
