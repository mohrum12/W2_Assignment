# Data Structures Mini-Notebook

This project contains a small Jupyter notebook exploring Python's `zip()`.
